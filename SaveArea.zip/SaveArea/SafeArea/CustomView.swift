//
//  CustomView.swift
//  SafeArea
//
//  Created by EastElsoft on 2017/12/13.
//  Copyright © 2017年 EastElsoft. All rights reserved.
//

import UIKit

class CustomView: UIView {

    @IBOutlet weak var textView: UITextView!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    override func layoutSubviews() {
        super.layoutSubviews()
//        print("safeAreaLayoutGuide.layoutFrame:  \(safeAreaLayoutGuide.layoutFrame)")
//        print("self.textView.frame:   \(self.textView.frame)")
        if #available(iOS 9.0, *) {
            self.textView.frame = safeAreaLayoutGuide.layoutFrame

        }
    }
    
    override func layoutMarginsDidChange() {
//        self.textView.frame = safeAreaLayoutGuide.layoutFrame


    }
    
    override func safeAreaInsetsDidChange() {

    }
}
