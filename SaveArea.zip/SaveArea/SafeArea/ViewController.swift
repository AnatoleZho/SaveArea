//
//  ViewController.swift
//  SafeArea
//
//  Created by EastElsoft on 2017/12/13.
//  Copyright © 2017年 EastElsoft. All rights reserved.
//

import UIKit

struct ReferenceClass {
    var model: Model
}

class Model {
    let name = "🇨🇳"
    
    deinit {
        print("Model 对象释放了")
    }
}

class ViewController: UIViewController {

    var view1: CustomView!
    var view2: CustomView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        //导航遮盖视图影响布局
        self.navigationController?.navigationBar.isTranslucent = true
        if #available(iOS 7.0, *) {
            let edgeOptions: UIRectEdge = [.left, .right, .bottom]
            self.edgesForExtendedLayout = edgeOptions
        }
        
        var model: Model? = Model()
        let refrenceModel = ReferenceClass.init(model: model!)
        model = nil
        print(refrenceModel.model.name)
        print(model?.name ?? "")
        
        
        print(view.safeAreaInsets)
        // 无论是iPhone 8 还是 iPhone X 输出结果均为
        // UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        
        view1 = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)![0] as! CustomView
        view2 = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)![0] as! CustomView
        self.view.addSubview(view1 as UIView)
        self.view.addSubview(view2 as UIView)
        
        let screenW = UIScreen.main.bounds.size.width
        let screenH = UIScreen.main.bounds.size.height
        view1.frame = CGRect(
            x: 0,
            y: 0,
            width:screenW,
            height: 200)
        view2.frame = CGRect(
            x: 0,
            y: screenH - 200,
            width:screenW,
            height: 200)
    }
    override func viewWillLayoutSubviews() {
//        let insets = view.safeAreaInsets
//
//        view1.frame = CGRect.init(x: insets.left, y: insets.top, width: self.view.bounds.width - insets.left - insets.right, height: 100)
//        view2.frame = CGRect.init(x: insets.left, y: self.view.bounds.height - insets.bottom - 100, width: self.view.bounds.width - insets.left - insets.right, height: 100)
//
    }
    
    override func viewLayoutMarginsDidChange() {
        let insets = view.safeAreaInsets
//
//        view1.frame = CGRect.init(x: insets.left, y: insets.top, width: self.view.bounds.width - insets.left - insets.right, height: 100)
//        view2.frame = CGRect.init(x: insets.left, y: self.view.bounds.height - insets.bottom - 100, width: self.view.bounds.width - insets.left - insets.right, height: 100)
        
    }
    
    override func viewSafeAreaInsetsDidChange() {
        
    }
    

    
    override func viewDidAppear(_ animated: Bool) {
        print("")
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

