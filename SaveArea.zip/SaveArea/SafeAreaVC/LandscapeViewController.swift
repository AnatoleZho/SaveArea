//
//  LandscapeViewController.swift
//  SafeAreaVC
//
//  Created by EastElsoft on 2018/1/29.
//  Copyright © 2018年 EastElsoft. All rights reserved.
//

import UIKit

class LandscapeViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.orientationMask = .landscapeRight
        newOrientation(true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate

        appDelegate.orientationMask = [.landscapeLeft,.portrait,.landscapeRight]
        newOrientation(false)
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func newOrientation(_ fullScreen: Bool = true) {
        if fullScreen {
            UIDevice.current.setValue(NSNumber(value: 2), forKey: "orientation")
        } else {
            UIDevice.current.setValue(NSNumber(value: 0), forKey: "orientation")
            UIDevice.current.setValue(NSNumber(value: 1), forKey: "orientation")
            UIDevice.current.setValue(NSNumber(value: 2), forKey: "orientation")
            UIDevice.current.setValue(NSNumber(value: 3), forKey: "orientation")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
