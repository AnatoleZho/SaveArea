//
//  BaseViewController.swift
//  SafeAreaVC
//
//  Created by EastElsoft on 2018/1/26.
//  Copyright © 2018年 EastElsoft. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // 默认将导航隐藏
        self.navigationController?.isNavigationBarHidden = true
        // 减半透明设置为 true
        self.navigationController?.navigationBar.isTranslucent =  true
        
        // 无导航界面退出有导航界面时，出现遮挡视图问题解决
        if #available(iOS 7.0, *) {
            let edgeOptions: UIRectEdge = [.left, .bottom, .right]
            self.edgesForExtendedLayout = edgeOptions
        }
        
    }

    override func viewWillAppear(_ animated: Bool) {
        if let hide = self.navigationController?.isNavigationBarHidden {
            if hide {
                self.navigationController?.setNavigationBarHidden(true, animated: animated)
            } else {
                self.navigationController?.setNavigationBarHidden(false, animated: animated)
            }
        } else {
            self.navigationController?.setNavigationBarHidden(true, animated: false)
        }
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
   
    // 设置状态栏颜色
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return [.portrait, .landscapeLeft, .landscapeRight]
    
    }
    
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .portrait
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
