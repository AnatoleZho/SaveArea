//
//  CollectionViewCell.swift
//  SafeAreaVC
//
//  Created by EastElsoft on 2018/1/26.
//  Copyright © 2018年 EastElsoft. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
