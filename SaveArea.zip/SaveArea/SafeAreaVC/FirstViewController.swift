//
//  FirstViewController.swift
//  SafeAreaVC
//
//  Created by EastElsoft on 2018/1/25.
//  Copyright © 2018年 EastElsoft. All rights reserved.
//

import UIKit


class FirstViewController: BaseViewController {

    
    var view1: CustomView!
    var view2: CustomView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(NSStringFromClass(FirstViewController.self),#function)

        //导航遮盖视图影响布局
        self.navigationController?.navigationBar.isTranslucent = true
        if #available(iOS 7.0, *) {
            let edgeOptions: UIRectEdge = [.left, .right, .bottom]
            self.edgesForExtendedLayout = edgeOptions
        }
        
        view1 = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)![0] as! CustomView
        view2 = Bundle.main.loadNibNamed("CustomView", owner: self, options: nil)![0] as! CustomView
        self.view.addSubview(view1 as UIView)
        self.view.addSubview(view2 as UIView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print(NSStringFromClass(FirstViewController.self),#function)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print(NSStringFromClass(FirstViewController.self),#function)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print(NSStringFromClass(FirstViewController.self),#function)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print(NSStringFromClass(FirstViewController.self),#function)
    }
    

    override func viewSafeAreaInsetsDidChange() {
        if #available(iOS 11.0, *) {
            let insets = view.safeAreaInsets
            //
            view1.frame = CGRect.init(x: insets.left, y: insets.top, width: self.view.bounds.width - insets.left - insets.right, height: 100)
            view2.frame = CGRect.init(x: insets.left, y: self.view.bounds.height - insets.bottom - 100, width: self.view.bounds.width - insets.left - insets.right, height: 100)
        } else {
            // Fallback on earlier versions
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func landscapeAction(_ sender: Any) {
        let landscapeVC = LandscapeViewController.init(nibName: "LandscapeViewController", bundle: nil)
        self.navigationController?.pushViewController(landscapeVC, animated: true)
    }
    
    @IBAction func landscapePortaitAction(_ sender: UIButton) {
        let landscapePortraitVC = LandscapePortraitController.init(nibName: "LandscapePortraitController", bundle: nil)
        self.navigationController?.pushViewController(landscapePortraitVC, animated: true)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
